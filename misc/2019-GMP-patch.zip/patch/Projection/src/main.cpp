//run fromthe projection source directory
//../../build_cmake/examples/Projection/project

#include "World.h"
#include <stdio.h>
#include <iostream>

int main(int argc, char** argv) {
	World world;
	std::string jsonFile("config/test.json");
	if(argc != 2) {
		std::cout << "Usage: ./" << argv[0] << " [input json file]" << std::endl;
		std::exit(0);
	}
	jsonFile = std::string(argv[1]);
    world.init(jsonFile);

    int step = 0, frame = 0;

	int fps = world.simFPS();
	int stepsPerFrame = world.simStepsPerFrame();
    int totalFrames = world.simTotalFrames();
    while(frame < totalFrames) {
        world.step();
        if(step % stepsPerFrame == 0) {
            world.renderObj(frame);
            frame++;
            world.printAveTime(frame);
        }
        step++;
        // std::exit(0);
    }

    world.printEnergyDiff();

    return 0;
}
