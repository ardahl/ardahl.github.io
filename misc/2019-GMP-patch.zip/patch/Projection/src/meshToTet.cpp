#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main(int argc, char** argv) {
    if(argc != 2) {
        cout << "Usage: " << argv[0] << " [file base]" << endl;
        exit(0);
    }
    string base = string(argv[1]);
    string f = base+string(".mesh");
    ifstream mesh(f);
    if(!mesh) {
        cout << "Could not open file " << f << endl;
        exit(0);
    }

    vector<vector<double> > verts;
    vector<vector<int> > tris, tets;

    string word, junk;
    //Read vertices
    while(word != "Vertices") {
        mesh >> word;
    }
    int numVerts = 0;
    mesh >> numVerts;
    verts.reserve(numVerts);
    for(int i = 0; i < numVerts; i++) {
        double x, y, z;
        mesh >> x >> y >> z >> junk;
        vector<double> v {x, y, z};
        verts.push_back(v);
    }
    //Read triangles
    while(word != "Triangles") {
        mesh >> word;
    }
    int numTris = 0;
    mesh >> numTris;
    tris.reserve(numTris);
    for(int i = 0; i < numTris; i++) {
        int x, y, z;
        mesh >> x >> y >> z >> junk;
        vector<int> v {x, y, z};
        tris.push_back(v);
    }
    //Read tetrahedrals
    while(word != "Tetrahedra") {
        mesh >> word;
    }
    int numTets = 0;
    mesh >> numTets;
    tets.reserve(numTets);
    for(int i = 0; i < numTets; i++) {
        int x, y, z, w;
        mesh >> x >> y >> z >> w >> junk;
        vector<int> v {x, y, z, w};
        tets.push_back(v);
    }
    mesh.close();

    string n = base+string(".node");
    ofstream tetgen(n);
    tetgen << verts.size() << " 3 0 0" << endl;
    for(int i = 0; i < verts.size(); i++) {
        tetgen << i << " " << verts[i][0] << " " << verts[i][1] << " " << verts[i][2] << endl;
    }
    tetgen.close();
    n = base+string(".ele");
    tetgen.open(n);
    tetgen << tets.size() << " 4 0" << endl;
    for(int i = 0; i < tets.size(); i++) {
        tetgen << i << " " << tets[i][1]-1 << " " << tets[i][0]-1 << " " << tets[i][2]-1 << " " << tets[i][3]-1 << endl;
    }
    tetgen.close();

    return 0;
}
