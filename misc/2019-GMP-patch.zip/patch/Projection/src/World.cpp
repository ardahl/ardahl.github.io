#include "World.h"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include "json/json.h"

template <class T>
T clamp(T a, T min, T max) {
    if(a < min) {
        return min;
    }
    else if(a > max) {
        return max;
    }
    else {
        return a;
    }
}

World::World() {
    steps = 0;
    time = 0;
    aveTime = 0;

    maxLinMom = maxAngMom = maxKinEnergy = 0;
    minLinMom = minAngMom = minKinEnergy = std::numeric_limits<double>::max();
}

World::~World() {
    for(int j = 0; j < m_collisionShapes.size(); j++) {
        btCollisionShape* shape = m_collisionShapes[j];
        m_collisionShapes[j] = 0;
        delete shape;
    }

    //delete dynamics world
    delete m_dynamicsWorld;
    //delete solver
    delete m_solver;
    //delete broadphase
    delete m_broadphase;
    //delete dispatcher
    delete m_dispatcher;

    delete m_collisionConfiguration;
    m_collisionShapes.clear();
}

void World::init(std::string input) {
    createEmptyDynamicsWorld();

    printf("Input: %s\n", input.c_str());
    if(input == "simple") {
        createSimple();
    }
    else {
        parseJson(input);
    }
}

void World::createEmptyDynamicsWorld() {
    m_collisionConfiguration = new btSoftBodyRigidBodyCollisionConfiguration();
    m_dispatcher = new btCollisionDispatcher(m_collisionConfiguration);

    m_broadphase = new btDbvtBroadphase();

    m_solver = new btSequentialImpulseConstraintSolver;

    m_dynamicsWorld = new btSoftRigidDynamicsWorld(m_dispatcher, m_broadphase, m_solver, m_collisionConfiguration);
    m_dynamicsWorld->setGravity(btVector3(0, 0, 0));

    worldInfo.m_broadphase = m_broadphase;
    worldInfo.m_dispatcher = m_dispatcher;
    worldInfo.m_gravity = m_dynamicsWorld->getGravity();
    worldInfo.m_sparsesdf.Initialize();
}

//Options:
//  fps: int, 30
//  steps: int, 1
//  dt: double, 1/30
//  simTime: int, 10
//  output: string, output
//  gravity: bool, true
//  floor: bool, true
//  Objects:
//      mesh: string, meshes/sphere
//      translation: vector, (0,0,0)
//      rotation: vector, (0,0,0)
//      scale: vector, (1,1,1)
//      initVelType: string, None
//      [initVelType=Linear]initVel: vector, (1,0,0)
//      [initVelType=Rotation]initVel: double, 1
//      mass: double, 1000
//      damping: double, 0
//      stiffness: double, 1
void World::parseJson(std::string input) {
    Json::Value root;
    Json::Reader jReader;
    std::ifstream ins(input.c_str());

    if(!jReader.parse(ins, root)){
        std::cout << "couldn't read input file: " << input << '\n'
                  << jReader.getFormattedErrorMessages() << std::endl;
        std::exit(1);
    }

    //FPS and sim time
    fps = root.get("fps", 30).asInt();
    framerate = 1.0/fps;
    auto dtIn = root["dt"];
    if(dtIn.isNull()) {
        //if dt not there, check if steps is
        auto stepsIn = root["steps"];
        if(stepsIn.isNull()) {
            //nothing there, just set a default
            printf("No steps or dt\n");
            dt = 1.0 / fps;
            stepsFrame = 1;
        }
        else {
            stepsFrame = stepsIn.asInt();
            dt = (1.0/(double)fps)/stepsFrame;
        }
    }
    else {
        dt = dtIn.asDouble();
        stepsFrame = (int)std::round((1.0/(double)fps)/dt);
    }
	stopTime = root.get("simTime", 10).asInt();
    //Output info
    std::string ol = root.get("output", "output/").asString();
    if(ol.back() != '/') {
        ol += "/";
    }
    setOutputLoc(ol);
    //Gravity
    bool useGrav = root.get("gravity", true).asBool();
    if(!useGrav) {
        printf("No Gravity\n");
        m_dynamicsWorld->setGravity(btVector3(0, 0, 0));
        worldInfo.m_gravity = m_dynamicsWorld->getGravity();
    }
    else {
        printf("Gravity On\n");
        m_dynamicsWorld->setGravity(btVector3(0, -9.81, 0));
        worldInfo.m_gravity = m_dynamicsWorld->getGravity();
    }
    //Bounds (floor, wall)
    // double bsize = root.get("bounds", 15.0).asDouble();
    // if(bsize > 0) {
    //     initBounds(bsize);
    // }
    auto bind = root["bounds"];
    btVector4 bnds(-15.0, 15.0, -15.0, 15.0);
    if(bind.size() == 1) {
        double size = bind[0].asDouble();
        if(size > 0) {
            bnds = btVector4(-size, size, -size, size);
            // initBounds(bnds);
        }
    }
    else if(bind.size() == 4) {
        double mx, px, mz, pz;
        mx = bind[0].asDouble();
        px = bind[1].asDouble();
        mz = bind[2].asDouble();
        pz = bind[3].asDouble();
        bnds = btVector4(mx, px, mz, pz);
    }
    printf("Bounds: %f, %f, %f, %f\n", bnds[0], bnds[1], bnds[2], bnds[3]);
    bool floor = root.get("floor", true).asBool();
    initBounds(bnds, floor);
    //Objects
    auto objectsIn = root["objects"];
    int nobjects = objectsIn.size();
    for(int i = 0; i < nobjects; i++) {
        SoftBodyCreateInfo setup;
        std::string btype = objectsIn[i].get("type", "soft").asString();
        BodyType type = BodyType::SoftBody;
        if(btype == "rigid") {
            type = BodyType::RigidBody;
        }
        std::string meshpath = objectsIn[i].get("mesh", "meshes/sphere").asString();
        btVector3 translate(0,0,0);
        btVector3 rotate(0,0,0);
        btVector3 scale(1,1,1);
        auto transIn = objectsIn[i]["translation"];
        if(transIn.size() == 3) {
            translate.setX(transIn[0].asDouble());
            translate.setY(transIn[1].asDouble());
            translate.setZ(transIn[2].asDouble());
        }
       //Rotation
       auto rotIn = objectsIn[i]["rotation"];
       if(rotIn.size() == 3) {
           double degToRad = M_PI/180.0;
           rotate.setX(rotIn[0].asDouble()*degToRad);
           rotate.setY(rotIn[1].asDouble()*degToRad);
           rotate.setZ(rotIn[2].asDouble()*degToRad);
       }
       //Scaling
       auto scaleIn = objectsIn[i]["scale"];
       if(scaleIn.size() == 3) {
           double degToRad = M_PI/180.0;
           scale.setX(scaleIn[0].asDouble());
           scale.setY(scaleIn[1].asDouble());
           scale.setZ(scaleIn[2].asDouble());
       }
        //Initial velocity
        //If it's linear, the other input is a vector of the Velocity
        //If it's rotational, the input is a scalar of the rotational field multiplier
        std::string opt = objectsIn[i].get("initVelType", "None").asString();
        VelField initVel = VelField::None;
        btVector3 ivel(0,0,0);
        btScalar rotForce = 1;
        if(opt == "None") {
            initVel = VelField::None;
        }
        else if(opt == "Rotation") {
            initVel = VelField::Rotation;
            rotForce = objectsIn[i].get("initVel", 1.0).asDouble();
        }
        else if(opt == "Linear") {
            initVel = VelField::Linear;
            auto initVelIn = objectsIn[i]["initVel"];
            if(initVelIn.size() == 3) {
                ivel.setX(initVelIn[0].asDouble());
                ivel.setY(initVelIn[1].asDouble());
                ivel.setZ(initVelIn[2].asDouble());
            }
            else {
                ivel = btVector3(1,0,0);
            }
        }
        else {
            std::cout << "Unknown initial velocity option: " << opt << "\n";
        }
        //Mass
        double mass = objectsIn[i].get("mass", 1000).asDouble();
        //damping
        double linDamp = objectsIn[i].get("damping", 0).asDouble();
        linDamp = clamp(linDamp, 0.0, 1.0);
        //stiffness
        double linStiff = objectsIn[i].get("stiffness", 1).asDouble();
        linStiff = clamp(linStiff, 0.0, 1.0);

        //position constraint iters
        int piters = objectsIn[i].get("piters", 5).asInt();
        //cluster(soft-soft) constraint iters
        int citers = objectsIn[i].get("citers", 4).asInt();
        //number of clusters
        int ccount = objectsIn[i].get("clusters", 0).asInt();

        printf("Object %d\n", i);
        printf("Mesh: %s\n", meshpath.c_str());
        printf("Mass: %f\n", mass);
        printf("Damping: %f\n", linDamp);
        printf("Stiffness: %f\n", linStiff);

        //Put everything in a struct so that we can pass it as 1 variable
        setup.meshPath = meshpath;
        setup.type = type;
        setup.translate = translate;
        setup.rotate = rotate;
        setup.scale = scale;
        setup.fieldType = initVel;
        setup.rotForce = rotForce;
        setup.initVel = ivel;
        setup.mass = mass;
        setup.damping = linDamp;
        setup.stiffness = linStiff;
        setup.piters = piters;
        setup.citers = citers;
        setup.clusters = ccount;

        if(setup.type == BodyType::SoftBody) {
            createSoftBody(setup);
        }
        else {
            createRigidBody(setup);
        }
    }
}

//Special case for 2 node example.
//2 nodes, 1 link, very stiff, conflicting velocity
//Should damp with no damping
void World::createSimple() {
    Json::Value root;
    Json::Reader jReader;
    std::string input("config/simple.json");
    std::ifstream ins(input.c_str());

    if(!jReader.parse(ins, root)){
        std::cout << "couldn't read input file: " << input << '\n'
                  << jReader.getFormattedErrorMessages() << std::endl;
        std::exit(1);
    }

    //FPS and sim time
    fps = root.get("fps", 30).asInt();
    framerate = 1.0/fps;
    auto dtIn = root["dt"];
    if(dtIn.isNull()) {
        //if dt not there, check if steps is
        auto stepsIn = root["steps"];
        if(stepsIn.isNull()) {
            //nothing there, just set a default
            printf("No steps or dt\n");
            dt = 1.0 / fps;
            stepsFrame = 1;
        }
        else {
            stepsFrame = stepsIn.asInt();
            dt = (1.0/(double)fps)/stepsFrame;
        }
    }
    else {
        dt = dtIn.asDouble();
        stepsFrame = (int)std::round((1.0/(double)fps)/dt);
    }
    stopTime = root.get("simTime", 10).asInt();
    //Output info
    setOutputLoc(root.get("output", "output").asString());
    //Gravity
    bool useGrav = root.get("gravity", true).asBool();
    if(!useGrav) {
        m_dynamicsWorld->setGravity(btVector3(0, 0, 0));
        worldInfo.m_gravity = m_dynamicsWorld->getGravity();
    }
    else {
        printf("Gravity On\n");
        m_dynamicsWorld->setGravity(btVector3(0, -9.81, 0));
        worldInfo.m_gravity = m_dynamicsWorld->getGravity();
    }

    int nnode = 2;
    btAlignedObjectArray<btVector3> pos;
    pos.push_back(btVector3(-0.5,0,0));
    pos.push_back(btVector3(0.5,0,0));
    btSoftBody* obj = new btSoftBody(&worldInfo, nnode, &pos[0], 0);
    //Stiffness
    obj->m_materials[0]->m_kLST = 1;
    // obj->m_materials[0]->m_kLST = 0.003;
    obj->appendLink(0, 1, 0, true);
    obj->setTotalMass(200);
    obj->randomizeConstraints();
    //damping
    //mass proportional. 1-kDP
    obj->m_cfg.kDP = 0;
    // obj->m_cfg.kDP = 0.005;
    btSoftBody::tNodeArray& nodes = obj->m_nodes;
    nodes[0].m_v = btVector3(0,-3.5,0);
    nodes[1].m_v = btVector3(0,3.5,0);
    obj->initMomentum();
    getSoftDynamicsWorld()->addSoftBody(obj);

    ObjectInfo obinfo;
    obinfo.render = true;
    obinfo.name = "points";
    obinfo.renderMesh = false;
    obinfo.useSpheres = true;
    Sphere s;
    s.pos = btVector3(0,0,0);
    s.radius = 0.1;
    obinfo.spheres.push_back(s);
    obinfo.spheres.push_back(s);
    createSphereMeshes(obinfo);
    objs.push_back(obinfo);

    printf("Added Simple\n");
}

void World::initBounds(btVector4 bsize, bool floor) {
    //Floor size is a cube of the max half length
    double size = std::max(std::max(std::abs(bsize.x()), std::abs(bsize.y())), std::max(std::abs(bsize.z()), std::abs(bsize.w())))+1;
	// create a few basic rigid bodies
    btScalar mass(0.);
    if(floor) {
    	btBoxShape* groundShape = createBoxShape(btVector3(btScalar(size), btScalar(size), btScalar(size)));
    	m_collisionShapes.push_back(groundShape);
    	btTransform groundTransform;
    	groundTransform.setIdentity();
    	groundTransform.setOrigin(btVector3(0, -size, 0));
        {
    		createRigidBody(mass, groundTransform, groundShape, btVector4(0, 0, 1, 1));
            ObjectInfo obinfo;
            obinfo.name = "Floor";
            obinfo.render = true;
            obinfo.renderMesh = false;
            obinfo.useSpheres = false;
            obinfo.rigidNodes.push_back(btVector3(size,-size,size));
            obinfo.rigidNodes.push_back(btVector3(size,-size,-size));
            obinfo.rigidNodes.push_back(btVector3(size,size,-size));
            obinfo.rigidNodes.push_back(btVector3(size,size,size));
            obinfo.rigidNodes.push_back(btVector3(-size,-size,size));
            obinfo.rigidNodes.push_back(btVector3(-size,-size,-size));
            obinfo.rigidNodes.push_back(btVector3(-size,size,-size));
            obinfo.rigidNodes.push_back(btVector3(-size,size,size));
            obinfo.tris.push_back(Triangle(4,0,3));
            obinfo.tris.push_back(Triangle(4,3,7));
            obinfo.tris.push_back(Triangle(0,1,2));
            obinfo.tris.push_back(Triangle(0,2,3));
            obinfo.tris.push_back(Triangle(1,5,6));
            obinfo.tris.push_back(Triangle(1,6,2));
            obinfo.tris.push_back(Triangle(5,4,7));
            obinfo.tris.push_back(Triangle(5,7,6));
            obinfo.tris.push_back(Triangle(7,3,2));
            obinfo.tris.push_back(Triangle(7,2,6));
            obinfo.tris.push_back(Triangle(0,5,1));
            obinfo.tris.push_back(Triangle(0,4,5));
            objsRigid.push_back(obinfo);
    	}
    }
    //x - -x, y - +x, z - -z, w - +z
    double xlength = bsize.w() - bsize.z();
    double zlength = bsize.y() - bsize.x();
    //+x wall
    btBoxShape* px = createBoxShape(btVector3(btScalar(xlength), btScalar(xlength), btScalar(xlength)));
	m_collisionShapes.push_back(px);
	btTransform wallT;
	wallT.setIdentity();
	wallT.setOrigin(btVector3(xlength+bsize.y(), xlength-1, 0));
	createRigidBody(mass, wallT, px, btVector4(0, 0, 1, 1));
    ObjectInfo obinfo;
    obinfo.name = "+x";
    obinfo.render = false;
    obinfo.useSpheres = false;
    objsRigid.push_back(obinfo);
    //-x wall
    btBoxShape* mx = createBoxShape(btVector3(btScalar(xlength), btScalar(xlength), btScalar(xlength)));
	m_collisionShapes.push_back(mx);
	wallT.setIdentity();
	wallT.setOrigin(btVector3(-xlength+bsize.x(), xlength-1, 0));
	createRigidBody(mass, wallT, mx, btVector4(0, 0, 1, 1));
    obinfo.name = "-x";
    obinfo.render = false;
    obinfo.useSpheres = false;
    objsRigid.push_back(obinfo);
    //+z wall
    btBoxShape* pz = createBoxShape(btVector3(btScalar(zlength), btScalar(zlength), btScalar(zlength)));
	m_collisionShapes.push_back(pz);
	wallT.setIdentity();
	wallT.setOrigin(btVector3(0, zlength-1, zlength+bsize.w()));
	createRigidBody(mass, wallT, pz, btVector4(0, 0, 1, 1));
    obinfo.name = "+z";
    obinfo.render = false;
    obinfo.useSpheres = false;
    objsRigid.push_back(obinfo);
    //-z wall
    btBoxShape* mz = createBoxShape(btVector3(btScalar(zlength), btScalar(zlength), btScalar(zlength)));
	m_collisionShapes.push_back(mz);
	wallT.setIdentity();
	wallT.setOrigin(btVector3(0, zlength-1, -zlength+bsize.z()));
	createRigidBody(mass, wallT, mz, btVector4(0, 0, 1, 1));
    obinfo.name = "-z";
    obinfo.render = false;
    obinfo.useSpheres = false;
    objsRigid.push_back(obinfo);
}

void World::createSoftBody(const btScalar s, const int numX, const int numY, const int fixed) {
    btSoftBody* cloth = btSoftBodyHelpers::CreatePatch(worldInfo,
                                                       btVector3(-s / 2, s + 1, 0),
                                                       btVector3(+s / 2, s + 1, 0),
                                                       btVector3(-s / 2, s + 1, +s),
                                                       btVector3(+s / 2, s + 1, +s),
                                                       numX, numY,
                                                       fixed, true);

    cloth->getCollisionShape()->setMargin(0.001f);
    cloth->getCollisionShape()->setUserPointer((void*)cloth);
    cloth->generateBendingConstraints(2, cloth->appendMaterial());
    cloth->setTotalMass(10);
    //cloth->m_cfg.citerations = 10;
    //	cloth->m_cfg.diterations = 10;
    cloth->m_cfg.piterations = 5;
    cloth->m_cfg.kDP = 0.005f;
    getSoftDynamicsWorld()->addSoftBody(cloth);
}

void World::createSoftBody(const SoftBodyCreateInfo& info) {
    std::string eleFile = info.meshPath + std::string(".ele");
    std::string nodeFile = info.meshPath + std::string(".node");
    std::cout << "Reading tet files:\n" << nodeFile << "\n" << eleFile << std::endl;
    //The softbody create function doesn't actually read the files, it expects the input to be an ascii string of the entire file
    std::ifstream tetIn(nodeFile);
    if(!tetIn) {
        std::cout << "Can't find node file " << nodeFile << std::endl;
        std::exit(0);
    }
    std::stringstream sstr;
    sstr << tetIn.rdbuf();
    std::string nodeIn = sstr.str();
    tetIn.close();
    tetIn.open(eleFile);
    if(!tetIn) {
        std::cout << "Can't find element file " << eleFile << std::endl;
        std::exit(0);
    }
    sstr.str(std::string());
    sstr << tetIn.rdbuf();
    std::string eleIn = sstr.str();
    tetIn.close();
    // printf("Stiffness: %f\n", info.stiffness);
    btSoftBody* obj = btSoftBodyHelpers::CreateFromTetGenData(worldInfo, eleIn.c_str(), NULL, nodeIn.c_str(), true, true, true, info.stiffness, info.clusters);
    obj->setTotalMass(info.mass);
    obj->randomizeConstraints();

    ObjectInfo obinfo;
    obinfo.render = true;
    std::string objName = info.meshPath;
    obinfo.name = objName.erase(0, objName.find_last_of('/')+1);
    obinfo.renderMesh = false;
    readRenderMesh(info.meshPath, obinfo, obj);
    if(!obinfo.renderMesh) {
        extractSurface(obj, obinfo);
    }
    obinfo.useSpheres = false;
    objs.push_back(obinfo);

    obj->getCollisionShape()->setMargin(0.001f);
    obj->getCollisionShape()->setUserPointer((void*)obj);
    obj->generateBendingConstraints(2, obj->appendMaterial());
    obj->m_cfg.citerations = info.citers;
    //	obj->m_cfg.diterations = 10;
    obj->m_cfg.piterations = info.piters;
    // obj->m_cfg.kDP = 0.005f;
    obj->m_cfg.kDP = info.damping;
    obj->m_cfg.kDF = 0;
    //translate mesh to center of mass
    btVector3 com = obj->evaluateCom();
    printf("COM: (%f, %f, %f)\n", com.x(), com.y(), com.z());
    obj->translate(-com);

    obj->scale(info.scale);
    btQuaternion rot(0,0,0,0);
    rot.setEuler(info.rotate.y(), info.rotate.x(), info.rotate.z());
    obj->rotate(rot);
    obj->translate(info.translate);
    obj->setVelocity(info.initVel);
    if(info.fieldType == VelField::Rotation) {
        btSoftBody::tNodeArray& nodes = obj->m_nodes;
        // Calculate center of mass
        btVector3 com = obj->evaluateCom();
        // Add rotation
        for(int i = 0; i < nodes.size(); i++) {
            btScalar frc = info.rotForce;
            // btScalar frc = 100.0;
            btVector3 arm = nodes[i].m_x - com;
            btVector3 rot(arm.getX(), -arm.getZ(), arm.getY());
            // double m = nodes[i].m_m;
            nodes[i].m_v = frc*rot;
            // obj->addForce(frc*m*rot, i);
        }
    }
    obj->initMomentum();
    getSoftDynamicsWorld()->addSoftBody(obj);
}

void World::createRigidBody(const SoftBodyCreateInfo& info) {

}

void World::updateTriToTetMap(TriToTetMap &triToTetMap, int n, int x, int y, int z) {
  Triangle tri(x, y, z);
  if (triToTetMap.count(tri) == 0) {
    TriMap e(n, -1);
    triToTetMap.insert(TriToTetMap::value_type(tri,e));
  } else {
    triToTetMap.find(tri)->second[1] = n;
  }
}

bool World::extractSurface (const btSoftBody* body, ObjectInfo& tri) {
  TriToTetMap triToTetMap;
  unsigned int i;
	std::vector<Triangle> vtris;
	const btSoftBody::tTetraArray& t = body->m_tetras;

  for (i=0; i<t.size(); i++) {
    updateTriToTetMap(triToTetMap, i, t[i](0), t[i](2), t[i](1));
    updateTriToTetMap(triToTetMap, i, t[i](3), t[i](0), t[i](1));
    updateTriToTetMap(triToTetMap, i, t[i](3), t[i](2), t[i](0));
    updateTriToTetMap(triToTetMap, i, t[i](2), t[i](3), t[i](1));
  }

  for (TriToTetMap::const_iterator m=triToTetMap.begin(); m!=triToTetMap.end(); m++) {
    if (m->second[1] == -1) {
      vtris.push_back(m->first);
    }
  }
    tri.tris.reserve(vtris.size());
	for (unsigned int i=0; i<vtris.size(); i++) {
		tri.tris.push_back(vtris[i]);
	}

  return true;
}

btRigidBody* World::createRigidBody(float mass, const btTransform& startTransform, btCollisionShape* shape, const btVector4& color) {
    btAssert((!shape || shape->getShapeType() != INVALID_SHAPE_PROXYTYPE));

    //rigidbody is dynamic if and only if mass is non zero, otherwise static
    bool isDynamic = (mass != 0.f);

    btVector3 localInertia(0, 0, 0);
    if (isDynamic)
        shape->calculateLocalInertia(mass, localInertia);

        //using motionstate is recommended, it provides interpolation capabilities, and only synchronizes 'active' objects

#define USE_MOTIONSTATE 1
#ifdef USE_MOTIONSTATE
    btDefaultMotionState* myMotionState = new btDefaultMotionState(startTransform);

    btRigidBody::btRigidBodyConstructionInfo cInfo(mass, myMotionState, shape, localInertia);

    btRigidBody* body = new btRigidBody(cInfo);
    //body->setContactProcessingThreshold(m_defaultContactProcessingThreshold);

#else
    btRigidBody* body = new btRigidBody(mass, 0, shape, localInertia);
    body->setWorldTransform(startTransform);
#endif  //

    body->setUserIndex(-1);
    m_dynamicsWorld->addRigidBody(body);
    return body;
}

void World::step() {
    if(steps == 0) {
        eout.open(outLoc+"energy.txt");
        btVector3 totalLinMom(0.0,0.0,0.0);
        btVector3 totalAngMom(0.0,0.0,0.0);
        btSoftBody* psb = (btSoftBody*)getSoftDynamicsWorld()->getSoftBodyArray()[0];
        double potEnergy = 0;
        double kinEnergy = 0;
        const btSoftBody::tNodeArray& nodes = psb->m_nodes;
        btVector3 com = psb->evaluateCom();
        for(int i = 0; i < nodes.size(); i++) {
            btVector3 v = nodes[i].m_v;
            double m = 1.0/nodes[i].m_im;
            // btVector3 disp = nodes[i].m_x-ob.rest[i];
            btMatrix3x3 M(m, 0, 0, 0, m, 0, 0, 0, m);
            btVector3 Mv = M*v;
            btVector3 p = m*v;
            double vtMv = v.dot(Mv);
            kinEnergy += 0.5*vtMv;
            potEnergy += 0;
            totalLinMom += p;
            totalAngMom += (nodes[i].m_x-com).cross(p);
        }
        // eout << time << " " << totalLinMom.norm() << " " << totalAngMom.norm() << " " << kinEnergy << " " << potEnergy << "\n";
        eout << time << " " << totalLinMom.norm() << " " << totalAngMom.norm() << " " << kinEnergy << " " << potEnergy << " " << psb->m_pose.m_linMom.norm() << " " << psb->m_pose.m_angMom.norm() << "\n";
        minLinMom = std::min(minLinMom, totalLinMom.norm());
        maxLinMom = std::max(maxLinMom, totalLinMom.norm());
        minAngMom = std::min(minAngMom, totalAngMom.norm());
        maxAngMom = std::max(maxAngMom, totalAngMom.norm());
        minKinEnergy = std::min(minKinEnergy, kinEnergy);
        maxKinEnergy = std::max(maxKinEnergy, kinEnergy);
    }

    btClock timer;
    m_dynamicsWorld->stepSimulation(dt);
    unsigned long long int nsec = timer.getTimeNanoseconds();
    double timerSec = nsec / 1.0e9;
    aveTime += timerSec;
    steps++;
    time += dt;

    btVector3 totalLinMom(0.0,0.0,0.0);
    btVector3 totalAngMom(0.0,0.0,0.0);
    btSoftBody* psb = (btSoftBody*)getSoftDynamicsWorld()->getSoftBodyArray()[0];
    double potEnergy = 0;
    double kinEnergy = 0;
    const btSoftBody::tNodeArray& nodes = psb->m_nodes;
    btVector3 com = psb->evaluateCom();
    for(int i = 0; i < nodes.size(); i++) {
        btVector3 v = nodes[i].m_v;
        double m = 1.0/nodes[i].m_im;
        // btVector3 disp = nodes[i].m_x-ob.rest[i];
        btMatrix3x3 M(m, 0, 0, 0, m, 0, 0, 0, m);
        btVector3 Mv = M*v;
        btVector3 p = m*v;
        double vtMv = v.dot(Mv);
        kinEnergy += 0.5*vtMv;
        potEnergy += 0;
        totalLinMom += p;
        totalAngMom += (nodes[i].m_x-com).cross(p);
    }
    // eout << time << " " << totalLinMom.norm() << " " << totalAngMom.norm() << " " << kinEnergy << " " << potEnergy << "\n";
    eout << time << " " << totalLinMom.norm() << " " << totalAngMom.norm() << " " << kinEnergy << " " << potEnergy << " " << psb->m_pose.m_linMom.norm() << " " << psb->m_pose.m_angMom.norm() << "\n";
    minLinMom = std::min(minLinMom, totalLinMom.norm());
    maxLinMom = std::max(maxLinMom, totalLinMom.norm());
    minAngMom = std::min(minAngMom, totalAngMom.norm());
    maxAngMom = std::max(maxAngMom, totalAngMom.norm());
    minKinEnergy = std::min(minKinEnergy, kinEnergy);
    maxKinEnergy = std::max(maxKinEnergy, kinEnergy);
}

void World::printEnergyDiff() {
    printf("Min Linear Momentum: %f\n", minLinMom);
    printf("Max Linear Momentum: %f\n", maxLinMom);
    printf("Diff: %f, %.2f%% (%.2f%%)\n", maxLinMom-minLinMom, 100*minLinMom/maxLinMom, 100*(1.0-(minLinMom/maxLinMom)));
    printf("Min Angular Momentum: %f\n", minAngMom);
    printf("Max Angular Momentum: %f\n", maxAngMom);
    printf("Diff: %f, %.2f%% (%.2f%%)\n", maxAngMom-minAngMom, 100*minAngMom/maxAngMom, 100*(1.0-(minAngMom/maxAngMom)));
    printf("Min Kinetic Energy: %f\n", minKinEnergy);
    printf("Max Kinetic Energy: %f\n", maxKinEnergy);
    printf("Diff: %f, %.2f%% (%.2f%%)\n", maxKinEnergy-minKinEnergy, 100*minKinEnergy/maxKinEnergy, 100*(1.0-(minKinEnergy/maxKinEnergy)));
}

void World::renderObj(int frame, bool tetSurface) {
    renderObj(outLoc, frame, tetSurface);
}

void World::renderObj(std::string outputLoc, int frame, bool tetSurface) {
    btSoftRigidDynamicsWorld* softWorld = getSoftDynamicsWorld();

	for (int i = 0; i < softWorld->getSoftBodyArray().size(); i++) {
        ObjectInfo& ob = objs[i];
        if(!ob.render) {
            printf("Object set not to render\n");
            continue;
        }
		btSoftBody* psb = (btSoftBody*)softWorld->getSoftBodyArray()[i];
        const btSoftBody::tNodeArray& nodes = psb->m_nodes;
        std::stringstream ss;
        ss << outputLoc << ob.name << "-" << std::setfill('0') << std::setw(2) << i;
        ss << "." << std::setfill('0') << std::setw(4) << frame << ".obj";
        std::string fname = ss.str();
        printf("Writing output: %s\n", fname.c_str());
        std::ofstream out(fname, std::ios::out);
        if(ob.useSpheres) {
            const std::vector<Sphere>& spheres = ob.spheres;
            std::vector<btVector3> verts;
            std::vector<Triangle> tris;
            for(int s = 0; s < (int)spheres.size(); s++) {
                /* add vertices and triangles to master list */
                std::vector<btVector3> movedVerts(spheres[s].verts);
                for(int j = 0; j < (int)movedVerts.size(); j++) {
                    movedVerts[j] += nodes[s].m_x;
                }
                verts.insert(verts.end(), movedVerts.begin(), movedVerts.end());
                tris.insert(tris.end(), spheres[s].tris.begin(), spheres[s].tris.end());
            }

            for(int j = 0; j < (int)verts.size(); j++) {
        		out << std::fixed << std::setprecision(5) << "v " << verts[j].x() << " " << verts[j].y() << " " << verts[j].z() << std::endl;
        	}
        	for(int j = 0; j < (int)tris.size(); j++) {
        		out << "f " << tris[j](0)+1 << " " << tris[j](1)+1 << " " << tris[j](2)+1 << std::endl;
        	}
        }
        else if(!ob.renderMesh || tetSurface) {
        	for (unsigned int j=0; j<nodes.size(); j++) {
        		out << std::fixed << std::setprecision(5)<<"v "<<nodes[j].m_x.x()<<" "<<nodes[j].m_x.y()<<" "<<nodes[j].m_x.z()<<std::endl;
        	}

        	for (unsigned int j=0; j<ob.tris.size(); j++) {
        		out<<"f "<<ob.tris[j](0)+1<<" "<<ob.tris[j](1)+1<<" "<<ob.tris[j](2)+1<<std::endl;
        	}
        }
        else {
            // std::cout << "Render Mesh" << std::endl;
            const btSoftBody::tTetraArray& tets = psb->m_tetras;
            for(int j = 0; j < (int)ob.renderVerts.size(); j++) {
                const btSoftBody::Tetra &t = tets[ob.baryTets[j]];
                btVector3 renderPos = ob.renderBary[j].x()*nodes[t(0)].m_x+ob.renderBary[j].y()*nodes[t(1)].m_x+ob.renderBary[j].z()*nodes[t(2)].m_x+ob.renderBary[j].w()*nodes[t(3)].m_x;
                out << std::fixed << std::setprecision(5)<<"v "<<renderPos.x()<<" "<<renderPos.y()<<" "<<renderPos.z()<<std::endl;
            }
            for(int j = 0; j < (int)ob.renderTris.size(); j++) {
        		out<<"f "<<ob.renderTris[j](0)+1<<" "<<ob.renderTris[j](1)+1<<" "<<ob.renderTris[j](2)+1<<std::endl;
        	}
        }
        out.close();
	}
    int ind = 0;
    for(int i = 0; i < softWorld->getNumCollisionObjects(); i++) {
        btRigidBody* prb = btRigidBody::upcast(softWorld->getCollisionObjectArray()[i]);
        if(!prb) {
            continue;
        }
        ObjectInfo& ob = objsRigid[ind];
        if(!ob.render) {
            continue;
        }
        // btTransform transform = prb->getWorldTransform();
        btTransform transform = prb->getCenterOfMassTransform();
        transform.setRotation(prb->getOrientation());
        std::stringstream ss;
        ss << outputLoc << ob.name << "-" << std::setfill('0') << std::setw(2) << ind;
        ss << "." << std::setfill('0') << std::setw(4) << frame << ".obj";
        std::string fname = ss.str();
        printf("Writing output: %s\n", fname.c_str());
        std::ofstream out(fname, std::ios::out);
    	for (unsigned int j=0; j<ob.rigidNodes.size(); j++) {
            btVector3 npos = transform * ob.rigidNodes[j];
    		out<<"v "<<npos.getX()<<" "<<npos.getY()<<" "<<npos.getZ()<<std::endl;
    	}
        // btBoxShape* box = (btBoxShape*)prb->getCollisionShape();
        // for(unsigned int j = 0; j < box->getNumVertices(); j++) {
        //     btVector3 npos;
        //     box->getVertex(boxCorrespond[j], npos);
        //     out<<"v "<<npos.getX()<<" "<<npos.getY()<<" "<<npos.getZ()<<std::endl;
        // }

    	for (unsigned int j=0; j<ob.tris.size(); j++) {
    		out<<"f "<<ob.tris[j](0)+1<<" "<<ob.tris[j](1)+1<<" "<<ob.tris[j](2)+1<<" "<<std::endl;
    	}
        out.close();
        ind++;
    }
}

void World::subdivideSphere(std::vector<btVector3> &verts, std::vector<Triangle> &tris, btVector3 c, double r) {
    std::map<Edge, int> divisions; // Edge -> new vertex
    std::vector<Triangle> tris2;

	for (int i = 0; i < (int)tris.size(); i++) {
		// const int f0 = meshIn.triangles[i*3];
		// const int f1 = meshIn.triangles[i*3+1];
		// const int f2 = meshIn.triangles[i*3+2];
        const int f0 = tris[i](0);
		const int f1 = tris[i](1);
		const int f2 = tris[i](2);

		const btVector3 v0 = verts[f0];
		const btVector3 v1 = verts[f1];
		const btVector3 v2 = verts[f2];

		const int f3 = subdivideEdge(f0, f1, v0, v1, verts, divisions, c, r);
		const int f4 = subdivideEdge(f1, f2, v1, v2, verts, divisions, c, r);
		const int f5 = subdivideEdge(f2, f0, v2, v0, verts, divisions, c, r);

        tris2.push_back(Triangle(f0, f3, f5));
        tris2.push_back(Triangle(f3, f1, f4));
        tris2.push_back(Triangle(f4, f2, f5));
        tris2.push_back(Triangle(f3, f4, f5));
    }
    tris = tris2;
}

int World::subdivideEdge(int f0, int f1, const btVector3 &v0, const btVector3 &v1, std::vector<btVector3> &verts, std::map<Edge, int> &io_divisions, const btVector3 c, double r) {
	const Edge edge(f0, f1);
	auto it = io_divisions.find(edge);
	if(it != io_divisions.end()) {
		return it->second;
	}

    //Find midpoint
    const btVector3 mp = (v0 + v1) / 2.0;
    //Push midpoint to be distance r from center
	// const Eigen::Vector3d v = normalize(Vector3(0.5) * (v0 + v1));
    const btVector3 dir = (mp-c).normalized();
    const btVector3 v = c + r*dir;
	const int f = verts.size();
	verts.push_back(v);
	io_divisions.emplace(edge, f);
	return f;
}

void World::createSphereMeshes(ObjectInfo& info) {
    int totalVerts = 0;
    std::vector<Sphere>& spheres = info.spheres;
    for(int s = 0; s < (int)spheres.size(); s++) {
        //Icosahedron points
        std::vector<btVector3> vertices(12, btVector3(0,0,0));
        std::vector<Triangle> triangles(20, Triangle(0,0,0));
        btVector3 pt = spheres[s].pos;
        double phiaa  = 26.56505; /* phi needed for generation */
        double r = spheres[s].radius; /* any radius in which the polyhedron is inscribed */
        double phia = M_PI*phiaa/180.0; /* 2 sets of four points */
        double theb = M_PI*36.0/180.0;  /* offset second set 36 degrees */
        double the72 = M_PI*72.0/180;   /* step 72 degrees */
        // vertices[0] = pt + Eigen::Vector3d(0.0, 0.0, r);
        // vertices[11] = pt + Eigen::Vector3d(0.0, 0.0, -r);
        vertices[0] = btVector3(0.0, 0.0, r);
        vertices[11] = btVector3(0.0, 0.0, -r);
        double the = 0.0;
        for(int i = 1; i < 6; i++) {
            vertices[i].setX(r*std::cos(the)*std::cos(phia));
            vertices[i].setY(r*std::sin(the)*std::cos(phia));
            vertices[i].setZ(r*std::sin(phia));
            // vertices[i] += pt;
            the = the+the72;
        }
        the=theb;
        for(int i = 6; i < 11; i++) {
            vertices[i].setX(r*std::cos(the)*std::cos(-phia));
            vertices[i].setY(r*std::sin(the)*std::cos(-phia));
            vertices[i].setZ(r*std::sin(-phia));
            // vertices[i] += pt;
            the = the+the72;
        }
        /* map vertices to 20 faces */
        triangles[0] = Triangle(0,1,2);
        triangles[1] = Triangle(0,2,3);
        triangles[2] = Triangle(0,3,4);
        triangles[3] = Triangle(0,4,5);
        triangles[4] = Triangle(0,5,1);
        triangles[5] = Triangle(11,6,7);
        triangles[6] = Triangle(11,7,8);
        triangles[7] = Triangle(11,8,9);
        triangles[8] = Triangle(11,9,10);
        triangles[9] = Triangle(11,10,6);
        triangles[10] = Triangle(1,2,6);
        triangles[11] = Triangle(2,3,7);
        triangles[12] = Triangle(3,4,8);
        triangles[13] = Triangle(4,5,9);
        triangles[14] = Triangle(5,1,10);
        triangles[15] = Triangle(6,7,2);
        triangles[16] = Triangle(7,8,3);
        triangles[17] = Triangle(8,9,4);
        triangles[18] = Triangle(9,10,5);
        triangles[19] = Triangle(10,6,1);

        /* subdivide surface 1-2 times */
        pt = btVector3(0,0,0);
        subdivideSphere(vertices, triangles, pt, r);
        // subdivideSphere(vertices, triangles, pt, r);
        /* add index offset to triangles */
        for(int i = 0; i < (int)triangles.size(); i++) {
            triangles[i] = triangles[i] + Triangle(totalVerts, totalVerts, totalVerts);
        }
        totalVerts += vertices.size();
        spheres[s].verts = vertices;
        spheres[s].tris = triangles;
    }
}

bool World::fileExists(std::string loc) {
    if(FILE *file = fopen(loc.c_str(), "r")) {
        fclose(file);
        return true;
    } else {
        return false;
    }
}

void World::readRenderMesh(std::string path, ObjectInfo& info, const btSoftBody* obj) {
    std::string loc = path + "_render.obj";
    if(!fileExists(loc)) {
        std::cout << "No render mesh file " << loc << ". Using tetmesh surface." << std::endl;
        info.renderMesh = false;
        return;
    }
    std::ifstream robj(loc);
    if(!robj) {
        std::cout << "Could not open render mesh file " << loc << "\n";
        info.renderMesh = false;
        return;
    }
    std::cout << "Reading render mesh: " << loc << std::endl;
    std::string line;
    robj >> line;
    //Skip to vertices
    while(line != "v") {
        robj >> line;
    }
    //Read in vertices
    while(line == "v") {
        double x, y, z;
        robj >> x >> y >> z;
        info.renderVerts.push_back(btVector3(x,y,z));
        robj >> line;
    }
    //Skip to triangle faces
    while(line != "f") {
        robj >> line;
    }
    //Read triangles
    while(line == "f") {
        int a, b, c;
        robj >> line;
        if(line.find("/") != std::string::npos) {
            line.erase(line.find("/"));
        }
        a = std::stoi(line)-1;
        robj >> line;
        if(line.find("/") != std::string::npos) {
            line.erase(line.find("/"));
        }
        b = std::stoi(line)-1;
        robj >> line;
        if(line.find("/") != std::string::npos) {
            line.erase(line.find("/"));
        }
        c = std::stoi(line)-1;
        info.renderTris.push_back(Triangle(a,b,c));
        robj >> line;
    }
    info.renderMesh = true;
    std::cout << "Finding Bary Coordinates" << std::endl;
    findBaryCoords(info, obj);
}

void World::findBaryCoords(ObjectInfo& info, const btSoftBody* obj) {
    //if the weights file exists, read that instead
    info.renderBary.reserve(info.renderVerts.size());
    info.baryTets.reserve(info.renderVerts.size());
    std::string weightsLoc = outLoc + info.name + "_weights.txt";
    std::cout << "Checking for weights file: " << weightsLoc << "\n";
    if(fileExists(weightsLoc)) {
        std::cout << "Weights file exists, reading\n";
        std::ifstream inweights(weightsLoc);
        int i = 0;
        //format is tetInd b1 b2 b3 b4
        //first item is the count for a sanity check
        int wCount = 0;
        inweights >> wCount;
        if(wCount == info.renderVerts.size()) {
            while(!inweights.eof() && i < wCount) {
                int t;
                inweights >> t;
                info.baryTets.push_back(t);
                double w1, w2, w3, w4;
                inweights >> w1 >> w2 >> w3 >> w4;
                info.renderBary.push_back(btVector4(w1, w2, w3, w4));
                i++;
            }
            info.renderMesh = true;
            return;
        }
        else {
            std::cout << "Render mesh weights file " << weightsLoc << " vertex count discrepency\n";
            std::cout << "File says " << wCount << " vs Mesh size " << info.renderVerts.size() << "\n";
        }
    }
    std::cout << "No weights file, creating weights\n";
    const btSoftBody::tTetraArray& tets = obj->m_tetras;
    for(int i = 0; i < (int)info.renderVerts.size(); i++) {
        btVector3 p = info.renderVerts[i];
        bool tetFound = false;
        for(int j = 0; j < tets.size(); j++) {
            double bary[4];
            if(pointInTet(p, tets[j], bary)) {
                info.renderBary.push_back(btVector4(bary[0], bary[1], bary[2], bary[3]));
                info.baryTets.push_back(j);
                tetFound = true;
                break;
            }
        }
        if(!tetFound) {
            std::cout << i << " (" << p.x() << ", " << p.y() << ", " << p.z() << ")\n";
            std::cout << "Render mesh not fully encompased by tet mesh. Switching to skin.\n";
            info.renderMesh = false;
            return;
        }
    }

    std::ofstream weightsOut(weightsLoc);
    weightsOut << info.renderVerts.size() << "\n";
    for(int i = 0; i < info.renderVerts.size(); i++) {
        weightsOut << info.baryTets[i] << " " << info.renderBary[i].x() << " " << info.renderBary[i].y() << " " << info.renderBary[i].z() << " " << info.renderBary[i].w() << "\n";
    }
    weightsOut.close();
    std::cout << "Dumping new weights to " << weightsLoc << "\n";
}

bool World::pointInTet(btVector3 p, btSoftBody::Tetra t, double bary[]) {
    btVector3 ap = p - t.m_n[0]->m_x;
    btVector3 ab = t.m_n[1]->m_x - t.m_n[0]->m_x;
    btVector3 ac = t.m_n[2]->m_x - t.m_n[0]->m_x;
    btVector3 ad = t.m_n[3]->m_x - t.m_n[0]->m_x;
    btVector3 bp = p - t.m_n[1]->m_x;
    btVector3 bc = t.m_n[2]->m_x - t.m_n[1]->m_x;
    btVector3 bd = t.m_n[3]->m_x - t.m_n[1]->m_x;
    double V = (1.0/6.0) * (ab.dot(ac.cross(ad)));
    double Va = (1.0/6.0) * (bp.dot(bd.cross(bc)));
    double Vb = (1.0/6.0) * (ap.dot(ac.cross(ad)));
    double Vc = (1.0/6.0) * (ap.dot(ad.cross(ab)));
    double Vd = (1.0/6.0) * (ap.dot(ab.cross(ac)));
    bary[0] = Va/std::abs(V);
    bary[1] = Vb/std::abs(V);
    bary[2] = Vc/std::abs(V);
    bary[3] = Vd/std::abs(V);
    return (bary[0]>=0 && bary[1]>=0 && bary[2]>=0 && bary[3]>=0 && std::abs(bary[0]+bary[1]+bary[2]+bary[3]-1) < 1e-4);
}

void World::printAveTime(int frame) {
    printf("Projection:\n");
    double totalAve = 0;
    btSoftRigidDynamicsWorld* softWorld = getSoftDynamicsWorld();

    for (int i = 0; i < softWorld->getSoftBodyArray().size(); i++) {
        ObjectInfo& ob = objs[i];
		btSoftBody* psb = (btSoftBody*)softWorld->getSoftBodyArray()[i];
        printf(" Object %d: %f\n", i, psb->aveProjTime/steps);
        totalAve += psb->aveProjTime;
    }
    printf("Average Proj: %e, %e\n", totalAve/frame, totalAve/steps);
    printf("Average Proj: %f, %f\n", totalAve/frame, totalAve/steps);
    printf("Total Proj: %f\n", totalAve);
    printf("Average Time: %e, %e\n", aveTime/frame, aveTime/steps);
    printf("Average Time: %f, %f\n", aveTime/frame, aveTime/steps);
    printf("Total Time: %f\n", aveTime);
    printf("Percentage Proj: %f%%\n\n", 100.0*totalAve/aveTime);
}
