#ifndef __WORLD_H__
#define __WORLD_H__

#include "btBulletDynamicsCommon.h"
#include "LinearMath/btVector3.h"
#include "LinearMath/btAlignedObjectArray.h"
#include "../../CommonInterfaces/CommonRigidBodyBase.h"

#include "BulletSoftBody/btSoftRigidDynamicsWorld.h"
#include "BulletSoftBody/btSoftBodyHelpers.h"
#include "BulletSoftBody/btSoftBodyRigidBodyCollisionConfiguration.h"

#include <string>
#include <vector>
#include <unordered_map>
#include <fstream>
#include <map>

enum class VelField {
    None,
    Linear,
    Rotation
};

enum class BodyType {
    SoftBody,
    RigidBody
};

struct SoftBodyCreateInfo {
    BodyType type;
    std::string meshPath;
    btVector3 translate;
    btVector3 rotate;
    btVector3 scale;
    VelField fieldType;
    btScalar rotForce;
    btVector3 initVel;
    btScalar mass;
    btScalar damping;
    btScalar stiffness;
    int citers;
    int piters;
    int clusters;
};

class World {
public:
    World();
    ~World();
    void init(std::string input);
    void step();
    void renderObj(int frame, bool tetSurface = false);
    void renderObj(std::string outputLoc, int frame, bool tetSurface = false);
    btSoftRigidDynamicsWorld* getSoftDynamicsWorld() { return (btSoftRigidDynamicsWorld*)m_dynamicsWorld; }
    void createSoftBody(const SoftBodyCreateInfo& info);
    void createRigidBody(const SoftBodyCreateInfo& info);
    void createSimple();
    void setOutputLoc(std::string out) { outLoc = out; }
    int simFPS() { return fps; }
    int simStepsPerFrame() { return stepsFrame; }
    int simTotalFrames() { return fps*stopTime; }
    void printAveTime(int frame);

    void printEnergyDiff();

private:
    class Triangle {
    public:
        unsigned int indices[3];
        Triangle(int a, int b, int c) { indices[0] = a; indices[1] = b; indices[2] = c; }
        inline unsigned int &operator()(const unsigned int &i) { return indices[i]; }
        inline unsigned int operator()(const unsigned int &i) const { return indices[i]; }
        inline unsigned int &operator[](const unsigned int &i) { return indices[i]; }
        inline unsigned int operator[](const unsigned int &i) const { return indices[i]; }
        inline Triangle operator+(const Triangle& t) { return Triangle(indices[0]+t[0], indices[1]+t[1], indices[2]+t[2]); }
    };
    struct Edge {
        int v0, v1;
        Edge(int v0, int v1)
    		: v0(v0 < v1 ? v0 : v1)
    		, v1(v0 < v1 ? v1 : v0)
    	{
    	}
    	bool operator <(const Edge &rhs) const {
    		return v0 < rhs.v0 || (v0 == rhs.v0 && v1 < rhs.v1);
        }
    };
    class TriMap {
    public:
        unsigned int values[2];
        TriMap(int a, int b) { values[0] = a; values[1] = b; }
        inline unsigned int &operator()(const unsigned int &i) { return values[i]; }
        inline unsigned int operator()(const unsigned int &i) const { return values[i]; }
        inline unsigned int &operator[](const unsigned int &i) { return values[i]; }
        inline unsigned int operator[](const unsigned int &i) const { return values[i]; }
    };
    struct Sphere {
        btVector3 pos;
        double radius;
        std::vector<btVector3> verts;
        std::vector<Triangle> tris;
    };
    struct ObjectInfo {
        std::string name;
        bool render;
        std::vector<btVector3> rigidNodes;
        std::vector<Triangle> tris;
        bool renderMesh;
        std::vector<btVector3> renderVerts;
        std::vector<Triangle> renderTris;
        std::vector<btVector4> renderBary;
        std::vector<int> baryTets;
        bool useSpheres;
        std::vector<Sphere> spheres;
    };
    struct eqTriangle3i {
      bool operator()(const Triangle &t1, const Triangle &t2) const {
        return ((t1(0) == t2(0) && t1(1) == t2(1) && t1(2) == t2(2)) ||
    	    (t1(1) == t2(0) && t1(0) == t2(1) && t1(2) == t2(2)) ||
    	    (t1(2) == t2(0) && t1(1) == t2(1) && t1(0) == t2(2)) ||
    	    (t1(0) == t2(0) && t1(2) == t2(1) && t1(1) == t2(2)) ||
    	    (t1(1) == t2(0) && t1(2) == t2(1) && t1(0) == t2(2)) ||
    	    (t1(2) == t2(0) && t1(0) == t2(1) && t1(1) == t2(2)));
      }
    };
    struct hashTriangle3i {
      size_t operator()(const Triangle& t) const {
        return (t(0) ^ t(1) ^ t(2));
      }
    };
    typedef std::unordered_map<Triangle, TriMap, hashTriangle3i, eqTriangle3i> TriToTetMap;
    bool fileExists(std::string loc);

    void createEmptyDynamicsWorld();
    void initBounds(btVector4 bsize, bool floor);
    void parseJson(std::string input);
    void createSoftBody(const btScalar s, const int numX, const int numY, const int fixed = 3);
    btBoxShape* createBoxShape(const btVector3& halfExtents)
	{
		btBoxShape* box = new btBoxShape(halfExtents);
		return box;
	}
    btRigidBody* createRigidBody(float mass, const btTransform& startTransform, btCollisionShape* shape, const btVector4& color = btVector4(1, 0, 0, 1));

    btSoftBodyWorldInfo worldInfo;
    //keep the collision shapes, for deletion/cleanup
	btAlignedObjectArray<btCollisionShape*> m_collisionShapes;
	btBroadphaseInterface* m_broadphase;
	btCollisionDispatcher* m_dispatcher;
	btConstraintSolver* m_solver;
	btDefaultCollisionConfiguration* m_collisionConfiguration;
	btDiscreteDynamicsWorld* m_dynamicsWorld;

    std::vector<ObjectInfo> objs;
    std::vector<ObjectInfo> objsRigid;
    int steps;
    double time;
    bool extractSurface(const btSoftBody* body, ObjectInfo& tri);
    void updateTriToTetMap(TriToTetMap &triToTetMap, int n, int x, int y, int z);
    std::ofstream eout;
    std::string outLoc;

    //Reading in render mesh
    void readRenderMesh(std::string path, ObjectInfo& info, const btSoftBody* obj);
    void findBaryCoords(ObjectInfo& info, const btSoftBody* obj);
    bool pointInTet(btVector3 p, btSoftBody::Tetra t, double bary[]);

    //Spheres for point simulations
    void createSphereMeshes(ObjectInfo& info);
    void subdivideSphere(std::vector<btVector3> &verts, std::vector<Triangle> &tris, btVector3 c, double r);
    int subdivideEdge(int f0, int f1, const btVector3 &v0, const btVector3 &v1, std::vector<btVector3> &verts, std::map<Edge, int> &io_divisions, const btVector3 c, double r);

    int fps, stepsFrame, stopTime;
    double dt, framerate;
    //energy values for comparison
    double maxLinMom, minLinMom;
    double maxAngMom, minAngMom;
    double maxKinEnergy, minKinEnergy;

    double aveTime;
};

#endif
